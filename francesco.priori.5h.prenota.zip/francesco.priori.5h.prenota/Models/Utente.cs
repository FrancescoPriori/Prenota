namespace francesco.priori._5h.prenota.Models;

public class Utente
{
    public string? Nome { get; set; }
    public string? Cognome { get; set; }
    public string? Email { get; set; }
    public string? Tipo { get; set; }
    public string? Citta { get; set; }

}